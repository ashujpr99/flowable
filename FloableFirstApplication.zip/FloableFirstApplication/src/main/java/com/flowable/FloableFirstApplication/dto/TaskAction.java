package com.flowable.FloableFirstApplication.dto;

import lombok.Data;

@Data
public class TaskAction {
	String action;
	String approved;
	String empId;
}
