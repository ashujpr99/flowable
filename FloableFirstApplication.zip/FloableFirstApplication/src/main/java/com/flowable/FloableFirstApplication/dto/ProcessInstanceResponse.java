package com.flowable.FloableFirstApplication.dto;

import lombok.AllArgsConstructor;
import lombok.Value;

@Value
@AllArgsConstructor
public class ProcessInstanceResponse {
  String processId;
  String message;
  boolean isEnded;
}
