package com.flowable.FloableFirstApplication.controller;

import java.util.List;



import org.flowable.engine.runtime.ProcessInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.flowable.FloableFirstApplication.dto.LoanRequest;
import com.flowable.FloableFirstApplication.dto.ProcessInstanceResponse;
import com.flowable.FloableFirstApplication.dto.TaskAction;
import com.flowable.FloableFirstApplication.dto.TaskDetails;

import com.flowable.FloableFirstApplication.service.PromoterService;


import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.AccessLevel;

@RestController
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@NoArgsConstructor
public class PromoterController {
	@Autowired
	 PromoterService promoterService;
	

	    //********************************************************** deployment endpoints **********************************************************
	    @PostMapping("/repository/deployments")
	    public String deployWorkflow() {
	    	promoterService.deployProcessDefinition();
	        return "New deployment has been created successfully";
	    }
	    //********************************************************** process endpoints **********************************************************
	    @PostMapping("/runtime/process-instances/{processId}")
	    public ProcessInstanceResponse applyHoliday(@RequestBody LoanRequest loanRequest, @PathVariable("processId") String processId) {
	        return promoterService.applyForLoan(loanRequest,processId);
	    }
	    
	  //********************************************************** task of a employee  **********************************************************
	    
	    
	    @GetMapping("runtime/tasks/{userName}")
	    public List<TaskDetails> getTasks(@PathVariable("userName") String userName) {
	        return promoterService.getTasks(userName);
	    }
	    
	    @GetMapping("runtime/groupTasks/{groupName}")
	    public List<TaskDetails> getGroupTasks(@PathVariable("groupName") String groupName) {
	        return promoterService.getGroupTasks(groupName);
	    }
	    
	  //********************************************************** complete/approval of task by manager **********************************************************
	    
	    
	    @PostMapping("runtime/tasks/{taskId}")
	    public String approveTask(@RequestBody TaskAction taskAction, @PathVariable("taskId") String taskId){	
	    	//System.out.println(taskId+"::::::::::::::::taskId:approved:::::::::::::"+Boolean.parseBoolean(taskAction.getApproved()));
	    	return  promoterService.approveLoan(taskId,taskAction);   
	    }
	  
	    
	  //********************************************************** getting all task of a process **********************************************************
		    
	    @GetMapping("runtime/process-instances/{processId}/task")
	    public List<TaskDetails> getAllProcessTasks(@PathVariable("processId") String processId) {
	        return promoterService.getAllProcessTasks(processId);
	    }
	    
	  //********************************************************** Getting process history **********************************************************
	    
		  
	    @GetMapping("/process/{processId}")
	    public String checkState(@PathVariable("processId") String processId){
	        return promoterService.checkProcessHistory(processId);
	        
	        
	    }
	    
	  

	    
	    
	  
}
