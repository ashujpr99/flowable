package com.flowable.FloableFirstApplication.dto;

import lombok.Data;

@Data
public class LoanRequest {

    String projectName;
    Long amount;
    String userName;
	String userId;
    String emailId;

}
