package com.flowable.FloableFirstApplication.service;

import java.util.ArrayList;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import org.flowable.engine.HistoryService;
import org.flowable.engine.ProcessEngine;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.history.HistoricActivityInstance;
import org.flowable.engine.repository.Deployment;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.form.api.FormInfo;
import org.flowable.form.api.FormModel;
import org.flowable.form.model.FormField;
import org.flowable.identitylink.api.IdentityLink;
import org.flowable.identitylink.api.IdentityLinkType;
import org.flowable.task.api.Task;
import org.flowable.task.api.history.HistoricTaskInstance;
import org.flowable.variable.api.persistence.entity.VariableInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flowable.FloableFirstApplication.dto.LoanRequest;
import com.flowable.FloableFirstApplication.dto.LoanRequest;
import com.flowable.FloableFirstApplication.dto.ProcessInstanceResponse;
import com.flowable.FloableFirstApplication.dto.TaskAction;
import com.flowable.FloableFirstApplication.dto.TaskDetails;
import org.flowable.form.model.SimpleFormModel;
import org.flowable.engine.impl.context.Context;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor(onConstructor = @__(@Autowired))
@NoArgsConstructor
public class PromoterService {




	    public static final String PROCESS_DEFINITION_KEY = "MahaRera";

	    ArrayList<Hashtable<String, String> > USERS = new ArrayList<Hashtable<String, String> >();
	    
	    RuntimeService runtimeService;
	    TaskService taskService;
	    ProcessEngine processEngine;
	    RepositoryService repositoryService;

    
	    
	    
	    //********************************************************** create new deployment **********************************************************

	    public void deployProcessDefinition() {

	        Deployment deployment =
	                repositoryService
	                        .createDeployment()
	                        .addClasspathResource("MahaRera.bpmn")
	                        .deploy();

	    }
	    
	    //********************************************************** Process instantiation (Apply for leaves) **********************************************************

		public ProcessInstanceResponse applyForLoan(LoanRequest loanRequest, String processId)
		{

		Task task=null;
		Map<String, Object> variables = new HashMap<String, Object>();
		variables.put("userName", loanRequest.getUserName());
		variables.put("userId", loanRequest.getUserId());
		variables.put("emailId", loanRequest.getEmailId());
		
		variables.put("amount", loanRequest.getAmount());
		variables.put("ProjectName", loanRequest.getProjectName());
		

		
		
		
		
		ProcessInstance processInstance =
		runtimeService.startProcessInstanceByKey(processId, variables);

		 Map<String, VariableInstance> processVariablesSaved = runtimeService.getVariableInstances(processInstance.getId());
		   
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+processVariablesSaved);
		
		return new ProcessInstanceResponse(processInstance.getId(), "Process has been instantiated successfully" ,processInstance.isEnded());
		}
	
		
		
		
		public String approveLoan(String taskId,TaskAction taskAction) {
			String response="";
			System.out.println("approveLoan taskId =="+taskId);
			Map<String, Object> variables = new HashMap<String, Object>();
		    variables.put("approved", Boolean.parseBoolean(taskAction.getApproved()));
		    if(taskAction.getAction().equals("assign"))
		    {
		    	taskService.claim(taskId, taskAction.getEmpId());
		    	response = "Task assigned to "+ taskAction.getEmpId();
		    }
		    else if(taskAction.getAction().equals("complete"))
		    {
		    	taskService.complete(taskId, variables);
		    	response = "Application has been aprroved" ;
		    }
    	
    
		    return response;  	
		}

		
		
	    public List<TaskDetails> getAllProcessTasks(String processId)
	    {
	     	List<Task> tasksAll =  processEngine.getTaskService()
	    		    .createTaskQuery()
	    		    .processInstanceId(processId)
	    		    .list();
	     	List<TaskDetails> taskDetails = getTaskAllDetails(tasksAll); 
	     		  
	     		 return taskDetails;
	     }	
		
		
	    private List<TaskDetails> getTaskAllDetails(List<Task> tasks) {
	        List<TaskDetails> taskDetails = new ArrayList<>();
	        for (Task task : tasks) {
	            Map<String, Object> processVariables = taskService.getVariables(task.getId());
	                      
	            taskDetails.add(new TaskDetails(task.getId(), task.getName(), processVariables));  
	            //task.getIdentityLinks().get(0).g
	        }
	        return taskDetails;
	    }
	     	
		public List<TaskDetails> getTasks(String userId) {
			 List<Task> tasks =null;
			 tasks = taskService.createTaskQuery().taskCandidateOrAssigned(userId).orderByTaskCreateTime().desc().list();
			List<TaskDetails> taskDetails = getTaskDetails(tasks);
		    System.out.println(taskDetails.size()+"==getTasks == userId=="+userId);
		    return taskDetails;
		}
		
		public List<TaskDetails> getGroupTasks(String groupName) {
			List<Task> tasks =null;		
			tasks = taskService.createTaskQuery().taskCandidateGroup(groupName).orderByTaskCreateTime().desc().list();	 
			List<TaskDetails> taskDetails = getTaskDetails(tasks);
		    System.out.println(taskDetails.size()+"==getTasks == groupName=="+groupName);
		    return taskDetails;
		}
		

private List<TaskDetails> getTaskDetails(List<Task> tasks) {
    List<TaskDetails> taskDetails = new ArrayList<>();
    for (Task task : tasks) {
        Map<String, Object> processVariables = taskService.getVariables(task.getId());
        taskDetails.add(new TaskDetails(task.getId(), task.getName(), processVariables));
    }
    return taskDetails;
}


public void acceptHoliday(String taskId) {
    taskService.complete(taskId);
}


public List<TaskDetails> getUserTasks(String empName) {
	List<Task> tasks = taskService.createTaskQuery().taskCandidateOrAssigned(empName).list();
    List<TaskDetails> taskDetails = getTaskDetails(tasks);
    return taskDetails;
}


public String checkProcessHistory(String processId) {

    HistoryService historyService = processEngine.getHistoryService();
    String returnStr="//******Audit Trail******\\";
    List<HistoricActivityInstance> activities =
            historyService
                    .createHistoricActivityInstanceQuery()
                    .processInstanceId(processId)
                    .finished()
                    .orderByHistoricActivityInstanceEndTime()
                    .asc()
                    .list();

    for (HistoricActivityInstance activity : activities) {
    	
    	returnStr = returnStr + "\n"+ activity.getActivityId() + " took " + activity.getDurationInMillis() + " milliseconds";
        System.out.println(
                activity.getActivityId() + " took " + activity.getDurationInMillis() + " milliseconds");
    }

    System.out.println("\n \n \n \n");
    return returnStr;
}


}


